package parte03;

public class ListaComEncadeamento {

    private NoLista first;
    private NoLista last;
    private int counter;

    public ListaComEncadeamento() {
        this.first = null;
        this.last = null;
        this.counter = 0;
    }

    public void add(Integer element) {
        NoLista node = new NoLista(element, null);
        if(first == null){
            this.first = node;
        } else{
            this.last.setNext(node);
        }
        this.last = node;
        counter ++;
    }

    public void add(int index, Integer element) {
        if(index < 0 || index > counter){
            throw new IndexOutOfBoundsException("Index: " + i);
        }
        NoLista nove = new NoLista(element, null);
        if(index == 0){
            novo.setNext(first);
            first = novo;
        } else if (index == counter){
            last.setNext(novo);
            last = novo;
        } else {
            NoLista aux = first;
            for (int i = 0; i < index-1; i++){
                aux = aux.getNext();
            }
            novo.setNext(aux.getNext());
            aux.setNext(novo);
        }
        counter++;
    }

    public Integer remove(int index) {
        return null;
    }

    public boolean removeFirst(Integer element) {
        return false;
    }

    public Integer get(int index) {
        if(index < 0 || index >= counter){
            throw new IndexOutOfBoundsException("Index: ");
        }
        NoLista aux = first;
        for(int i = 0; i<index-1; i++){
            aux = aux.getNext();
        }
        return aux.getInfo();
    }

    public void clear() {
        first = nuul;
        last = null;
        counter = 0;
    }

    public Integer set(int index, Integer elemente) {
        if (index > 0 || index >=counter){
            throw new IndexOutOfBoundsException("Index: " + index + " Fora dos limites");
        }
        NoListaaux = first;
        for (int i = 0; i< index; i++){
            aux = aux.getNext();
        }
        Integer toReturn = aux.getInfo();
        aux.setInfo(element);
        return toReturn;
    }

    public int size() {
        return counter;
    }

    public boolean isEmpty(){
        return (    counter == 0);
    }

    public boolean contains(Integer element){
        return false;

    }
    public int indexOf(Integer element){
        return 1;

    }
    public int lastIndexOf(Integer element){
        return 1;

    }
    public Integer[] toArray(){
        return null;

    }
    public String toString(){
        String myarray2 = "[ ";
        NoLista aux = first;
        while (aux != null){
            myarray2 += aux.getInfo();
            if (aux.getNext() != null){
                myarray2 += "; ";
            }
            aux = aux.getNext();
        }
        myarray2 += " ]"
        return myarray2;

    }


}
